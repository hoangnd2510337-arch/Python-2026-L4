from domains.models import students, courses, marks
import math

def addStudent(s_id,s_name,s_dob):
    studentadding = {"id" : s_id, 
            "name" : s_name,
            "dob" : s_dob,
            "gpa" : 0}

    students.append(studentadding)


def addCourse(id, name, credits):
    courseadding = {"id" : id,
                    "name" : name,
                    "credits" : credits}

    courses.append(courseadding)
    
def input_marks(course_id):
    if course_id not in marks:
        marks[course_id]={}

    print(f"Entering marks of course {course_id}")
    print("Enter -1 to exit")
    while True:
        input_id = input("Enter student ID: ")

        if input_id == "-1":
            break

        exists = 0
        for s in students:
            if s['id'] == input_id:
                exists = 1
                s_name = s['name']
                break

        if exists == 1:
            mark = float(input("Enter mark: "))
            marks[course_id][input_id] = math.floor(mark)
            print(f"Mark saved: {input_id} - {mark}")
        else:
            print("Student not exists")