from domains.models import students, courses, marks
import input, output
import curses

input.addCourse("A1","Optimization",3)
input.addCourse("ICT1","Python",4)
input.addCourse("MAT1","Probability",4)

input.addStudent("2510337","Hoang","26 Jan 2007")
input.addStudent("2510012","An","27 Oct 2007")
input.addStudent("2510123","Phong", "9 Mar 2007")

curses.wrapper(output.main_menu)