import numpy as np

students = []
courses = []
marks = {}

def calcGPA(sid):
    s_marks = []
    c_credits = []
    for c in courses:
        c_id = c['id']
        if c_id in marks and sid in marks[c_id]:
            s_marks.append(marks[c_id][sid])
            c_credits.append(c['credits'])

        if (s_marks == []):
            return 0

        np_marks = np.array(s_marks)
        np_credits = np.array(c_credits)

        gpa = np.average(marks, weight = credits)

        for s in students:
            if s['id'] == sid:
                s['gpa'] = gpa
                break

        return gpa

def sortGPA():
    students.sort(key=lambda s: s.get('gpa', 0), reverse = True)