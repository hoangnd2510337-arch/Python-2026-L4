import curses
import math
from domains.models import students, courses, marks

def main_menu(stdscr):
    curses.echo() 
    
    while True:
        stdscr.clear()
        menu = (
            "0. Exit\n"
            "1. List Courses\n"
            "2. List Students\n"
            "3. Marks of a course\n"
            "4. Edit marks\n\n"
            "Enter number to use function: "
        )
        stdscr.addstr(0, 0, menu)
        
        choice = stdscr.getstr().decode('utf-8')
        stdscr.clear()
        
        if choice == '0':
            break
            
        elif choice == '1':
            stdscr.addstr(0, 0, f"Courses: {courses}")
            
        elif choice == '2':
            stdscr.addstr(0, 0, f"Students: {students}")
            
        elif choice == '3':
            stdscr.addstr(0, 0, "Enter course ID: ")
            c_id = stdscr.getstr().decode('utf-8')
            stdscr.addstr(2, 0, f"Marks: {marks.get(c_id, 'No data')}")
            
        elif choice == '4':
            stdscr.addstr(0, 0, "Enter course ID: ")
            c_id = stdscr.getstr().decode('utf-8')
            
            if c_id not in marks:
                marks[c_id] = {}
                
            stdscr.addstr(1, 0, "Enter student ID: ")
            s_id = stdscr.getstr().decode('utf-8')
            
            stdscr.addstr(2, 0, "Enter mark: ")
            try:
                mark = float(stdscr.getstr().decode('utf-8'))
                marks[c_id][s_id] = math.floor(mark * 10) / 10
                stdscr.addstr(4, 0, f"Mark saved: {s_id} - {marks[c_id][s_id]}")
            except ValueError:
                stdscr.addstr(4, 0, "Invalid input!")

        if choice != '0':
            stdscr.addstr(6, 0, "Press Enter to continue...")
            stdscr.getstr()