import os
import zipfile
import curses
from domains.models import students, courses, marks
import input
import output

def load_data():
    """Check if students.dat exists, extract, and load into memory."""
    if os.path.exists("students.dat"):
        # 1. Decompress the archive
        with zipfile.ZipFile("students.dat", "r") as zf:
            zf.extractall()
            
        students.clear()
        courses.clear()
        marks.clear()

        # 3. Read students.txt
        if os.path.exists("students.txt"):
            with open("students.txt", "r") as fs:
                for line in fs:
                    # Based on f"{s_id:<10} {s_name:<15} {s_dob:<15}\n"
                    # We slice the string using the exact character widths
                    s_id = line[0:10].strip()
                    s_name = line[11:26].strip()
                    s_dob = line[27:].strip()
                    
                    if s_id: # Ensure the line isn't empty
                        students.append({
                            "id": s_id,
                            "name": s_name,
                            "dob": s_dob,
                            "gpa": 0
                        })

        # 4. Read courses.txt
        if os.path.exists("courses.txt"):
            with open("courses.txt", "r") as fc:
                for line in fc:
                    # Based on f"{id:<10} {name:<15} {credits:<2}\n"
                    c_id = line[0:10].strip()
                    c_name = line[11:26].strip()
                    c_credits_str = line[27:].strip()
                    
                    if c_id:
                        courses.append({
                            "id": c_id,
                            "name": c_name,
                            "credits": int(c_credits_str)
                        })

        # 5. Read marks.txt (if you used the space-separated format from earlier)
        if os.path.exists("marks.txt"):
            with open("marks.txt", "r") as fm:
                for line in fm:
                    parts = line.strip().split()
                    if len(parts) == 3:
                        c_id = parts[0]
                        s_id = parts[1]
                        mark = float(parts[2])
                        
                        # Initialize the course dictionary if it doesn't exist yet
                        if c_id not in marks:
                            marks[c_id] = {}
                            
                        # Save the mark
                        marks[c_id][s_id] = mark

def save_and_compress():
    with open("marks.txt", "w") as fm:
        for c_id, c_marks in marks.items():
            for s_id, mark in c_marks.items():
                fm.write(f"{c_id} {s_id} {mark}\n")

    # Compress all text files into students.dat using ZIP_DEFLATED
    with zipfile.ZipFile("students.dat", "w", zipfile.ZIP_DEFLATED) as zf:
        if os.path.exists("students.txt"):
            zf.write("students.txt")
        if os.path.exists("courses.txt"):
            zf.write("courses.txt")
        if os.path.exists("marks.txt"):
            zf.write("marks.txt")

load_data()

curses.wrapper(output.main_menu)

save_and_compress()